module.exports = async function (req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Método no permitido' });
  }

  const apiKey = process.env.AI_GATEWAY_API_KEY || process.env.VERCEL_OIDC_TOKEN;

  if (!apiKey) {
    return res.status(500).json({ error: 'Sin credenciales de AI Gateway' });
  }

  try {
    const body = req.body || {};

    // Acepta tanto nombres en español como los de la versión anterior.
    const pregunta = body.pregunta ?? body.question ?? '';
    const empresa = body.empresa ?? body.company ?? 'Todas';
    const tareas = body.tareas ?? body.tasks ?? [];
    const clientes = body.clientes ?? body.clients ?? [];

    const response = await fetch('https://ai-gateway.vercel.sh/v1/chat/completions', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${apiKey}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model: 'poolside/laguna-s-2.1-free',
        messages: [
          {
            role: 'system',
            content:
              'Eres Director IA de Carlos, su asistente ejecutivo personal. ' +
              'Responde siempre en español, de forma breve, práctica, clara y orientada a acciones. ' +
              'Analiza tareas, clientes y prioridades de la empresa seleccionada. ' +
              'Si faltan datos, dilo claramente y no inventes. ' +
              'Cuando sea útil, prioriza qué hacer primero y propone el siguiente paso concreto.'
          },
          {
            role: 'user',
            content:
              `Empresa seleccionada: ${empresa}\n` +
              `Tareas pendientes: ${JSON.stringify(tareas)}\n` +
              `Clientes y oportunidades: ${JSON.stringify(clientes)}\n` +
              `Pregunta: ${pregunta}`
          }
        ],
        max_tokens: 650,
        temperature: 0.3
      })
    });

    const data = await response.json().catch(() => ({}));

    if (!response.ok) {
      console.error('AI Gateway error:', response.status, data);
      return res.status(response.status).json({
        error: data?.error?.message || data?.error || `Gateway ${response.status}`
      });
    }

    const answer =
      data?.choices?.[0]?.message?.content ||
      data?.answer ||
      'Sin respuesta';

    return res.status(200).json({
      respuesta: answer,
      answer,
      modelo: data?.model || 'poolside/laguna-s-2.1-free'
    });
  } catch (e) {
    console.error('Director IA error:', e);
    return res.status(500).json({ error: 'Error interno del Director IA' });
  }
};
